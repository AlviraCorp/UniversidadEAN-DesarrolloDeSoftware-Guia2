/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

/**
 *
 * @author juans
 */
import modelo.CalculadoraImpuestos; // Se busca en el paquete "modelo"
import modelo.Vehiculo;             // Se busca en el paquete "modelo"
import vista.Grafica;               
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.NumberFormat;
import java.util.Locale;
import javax.swing.JOptionPane;

/**
 * Clase Controlador que maneja la interacción entre la Vista y el Modelo.
 */
public class ControladorVehiculo implements ActionListener {

    private final Grafica vista;
    private final CalculadoraImpuestos modeloCalculadora;

    public ControladorVehiculo(Grafica vista, CalculadoraImpuestos modelo) {
        this.vista = vista;
        this.modeloCalculadora = modelo;
        
        // Asignar los listeners a los botones de la vista
        this.vista.getBotonCalcular().addActionListener(this);
        this.vista.getBotonLimpiar().addActionListener(this);
    }

    /**
     * Inicia la vista y la hace visible.
     */
    public void iniciar() {
        vista.setTitle("Calculadora de Impuestos Vehiculares");
        vista.setLocationRelativeTo(null); // Centrar en pantalla
        vista.setVisible(true);
    }

    /**
     * Maneja los eventos de los botones.
     * @param e El evento de acción.
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vista.getBotonCalcular()) {
            ejecutarCalculo();
        } else if (e.getSource() == vista.getBotonLimpiar()) {
            vista.limpiarCampos();
        }
    }

    /**
     * Orquesta el proceso de cálculo del impuesto.
     */
    private void ejecutarCalculo() {
        try {
            // 1. Obtener el dato de la vista
            String textoAvaluo = vista.getTxtAvaluo().getText();
            if (textoAvaluo.isEmpty()) {
                JOptionPane.showMessageDialog(vista, "El campo 'Avalúo comercial' no puede estar vacío.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            double avaluo = Double.parseDouble(textoAvaluo);

            // 2. Validar el dato
            if (avaluo <= 0) {
                JOptionPane.showMessageDialog(vista, "El avalúo debe ser un valor positivo.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // 3. Crear el objeto del modelo
            Vehiculo vehiculo = new Vehiculo();
            vehiculo.setAvaluoComercial(avaluo);

            // 4. Pedir al modelo que realice el cálculo
            double total = modeloCalculadora.calcularTotalAPagar(vehiculo);

            // 5. Formatear y mostrar el resultado en la vista
            NumberFormat formatoMoneda = NumberFormat.getCurrencyInstance(new Locale("es", "CO"));
            formatoMoneda.setMaximumFractionDigits(0); // Para mostrar sin decimales
            
            vista.getTotal().setText("Valor a pagar: " + formatoMoneda.format(total));
            vista.getTotal().setForeground(new java.awt.Color(0, 100, 0)); // Color verde oscuro

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(vista, "Por favor, ingrese un valor numérico válido en 'Avalúo comercial'.", "Error de Formato", JOptionPane.ERROR_MESSAGE);
        }
    }
}
