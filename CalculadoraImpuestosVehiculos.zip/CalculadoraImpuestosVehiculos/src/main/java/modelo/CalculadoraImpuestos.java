/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author juans
 */
public class CalculadoraImpuestos {

    // Constantes para las tarifas y valores fijos (mejora la legibilidad)
    private static final double TARIFA_BAJA = 0.015;    // 1.5%
    private static final double TARIFA_MEDIA = 0.025;   // 2.5%
    private static final double TARIFA_ALTA = 0.035;    // 3.5%

    private static final double LIMITE_TARIFA_BAJA = 54057000;
    private static final double LIMITE_TARIFA_MEDIA = 121625000;
    
    private static final double DERECHOS_SEMAFORIZACION = 114500;

    public double calcularTotalAPagar(Vehiculo vehiculo) {
        double avaluo = vehiculo.getAvaluoComercial();
        double impuestoBase = 0;

        if (avaluo <= LIMITE_TARIFA_BAJA) {
            impuestoBase = avaluo * TARIFA_BAJA;
        } else if (avaluo <= LIMITE_TARIFA_MEDIA) {
            impuestoBase = avaluo * TARIFA_MEDIA;
        } else {
            impuestoBase = avaluo * TARIFA_ALTA;
        }

        return impuestoBase + DERECHOS_SEMAFORIZACION;
    }
}
