/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.calculadoraimpuestosvehiculos;

/**
 *
 * @author juans
 */
import Controlador.ControladorVehiculo;
import modelo.CalculadoraImpuestos;
import vista.Grafica;

/**
 * Clase principal que inicia la aplicación MVC.
 */
public class CalculadoraImpuestosVehiculos {

    public static void main(String[] args) {
        // Establecer un Look and Feel más moderno (Nimbus)
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ex) {
            java.util.logging.Logger.getLogger(Grafica.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        // Iniciar la aplicación en el hilo de despacho de eventos de Swing
        java.awt.EventQueue.invokeLater(() -> {
            // 1. Crear el Modelo
            CalculadoraImpuestos modelo = new CalculadoraImpuestos();

            // 2. Crear la Vista
            Grafica vista = new Grafica();

            // 3. Crear el Controlador y conectarlo
            ControladorVehiculo controlador = new ControladorVehiculo(vista, modelo);

            // 4. Iniciar la aplicación
            controlador.iniciar();
        });
    }
}
